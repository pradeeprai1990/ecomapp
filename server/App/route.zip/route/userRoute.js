const express = require('express')
let cors=require('cors');
let multer  = require('multer');
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads/category')
    },
    filename: function (req, file, cb) {
        cb(null, new Date().getTime()+file.originalname);
    }
  })
  
  const upload = multer({ storage: storage })

let userController=require("../controller/userController")

let router=express.Router();
router.post("/website/add-user",userController.addUser)
router.post("/website/login",userController.loginUser)
module.exports=router;