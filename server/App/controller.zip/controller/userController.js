
let express=require("express");
let userModels=require("../models/userModels")
let fs=require("fs");


exports.addUser=(async(req,res)=>{
    console.log(req.body)
    let data={
        uname:req.body.uname,
        uemail:req.body.uemail,
        uphone:req.body.uphone,
        uaddress:req.body.uaddress,
        upassword:req.body.upassword,
    }
    let dataInsert=await userModels(data)
    dataInsert.save().then((insertRes)=>{
        res.send(insertRes)
        
    })
    // .catch((error)=>{
    //     res.send(error)
    // })
    .catch((error)=>{
        let re;
        if(error.keyPattern.uemail===1){
             re={
                'status':0,
                'msg':'Email Id Already exists...'
            }
        }
        else if(error.keyPattern.uphone===1){
             re={
                'status':0,
                'msg':'Phone Number Already exists...'
            }
        }
        console.log(re)
       res.send(re)
   })
  
})

exports.loginUser=(async(req,res)=>{
    let uemail=req.body.uemail;
    let upassword=req.body.upassword;
    console.log(uemail, upassword)
    let userData=await userModels.findOne({"uemail":uemail,"upassword":upassword})
    res.send({"status":1,userData})
    console.log(userData)
})